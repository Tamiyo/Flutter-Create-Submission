//
//  Generated file. Do not edit.
//

#import "GeneratedPluginRegistrant.h"
#import <mlkit/MlkitPlugin.h>

@implementation GeneratedPluginRegistrant

+ (void)registerWithRegistry:(NSObject<FlutterPluginRegistry>*)registry {
  [MlkitPlugin registerWithRegistrar:[registry registrarForPlugin:@"MlkitPlugin"]];
}

@end
